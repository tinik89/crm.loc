/* Preloader */
$(window).on("load", function() {
	
	/*preload*/
	var preload = $('.preloader');
	preload.find('.spinner').fadeOut(function(){
		preload.fadeOut(500);
	});

});

$(function() {
	var width = $(window).width();
	var height = $(window).height();
    
    /* Main carousel 
	var owl_slider = $(".main-started .owl-carousel");
    
	owl_slider.owlCarousel({
		margin: 0,
		items: 1,
		autoplay: false,
		loop: false,
        rewind: true,
		nav: true,
		dots: true
	});*/
    
	/* Mobile Menu 
	$('.header').on('click', '.menu-btn', function(){
		if($('.header').hasClass('opened')) {
            $('.header').removeClass('opened');
            
            $('body, html').css({'overflow':'visible'});
            $('body, html').css({'height':'auto'});
		} else {
            $('.header').addClass('opened');
            
            $('body, html').css({'overflow':'hidden'});
            $('body, html').css({'height':'100vh'});
		}
		return false;
	});*/
	
	/* Gallery 
	$(".gallery-group").fancybox({
		// Options will go here
	});*/
    
    /* Tabs */
	$('.tab-menu a').click(function(){
		var tab_bl = $(this).attr('href');
		
		$(this).closest('.tabs').find('.tab-menu li').removeClass('active');
		$(this).parent().addClass('active');
		
		$(this).closest('.tabs').find('.tab-item').hide();
		$(tab_bl).fadeIn();

		return false;
	});
	
    /* Form Styler */
	if($('.styler').length) {
		$('input.styler, select.styler').styler();
	}
    
    /* Tel Mask */
    if($("input[name='tel']").length) {
		$("input[name='tel']").mask("+7 (999) 999-99-99",{placeholder:""});
	}
    
    if($('.m_switch_check:checkbox').length) {
    $(".m_switch_check:checkbox").mSwitch({
        onRendered: function(){},
        onRender: function(elem){},
        onTurnOn: function(elem){
            return true;
        },
        onTurnOff: function(elem){
            return true;
        }
    });
    }
    
    /* Client Popup */
	$('.add-client-btn, .contract-table .edit-btn.edit').click(function(){
		$('.overlay').fadeIn(250, function(){
			$('#client-popup').animate({'top': $(window).scrollTop() + 100}, 500);
		});
		return false;
	});
	$('.overlay, #client-popup .cancel-btn, #client-popup .close').click(function(){
		$('#client-popup').animate({'top': '-3000px'}, 500, function(){
			$('.overlay').fadeOut(250);
		});
		return false;
	});
    
    /* Payments Popup */
	$('.add-gr-btn.add-pay, .payments-table .edit-btn.edit').click(function(){
		$('.overlay').fadeIn(250, function(){
			$('#payments-popup').animate({'top': $(window).scrollTop() + 100}, 500);
		});
		return false;
	});
	$('.overlay, #payments-popup .cancel-btn, #payments-popup .close').click(function(){
		$('#payments-popup').animate({'top': '-3000px'}, 500, function(){
			$('.overlay').fadeOut(250);
		});
		return false;
	});
    
    /* Contact Popup */
	$('.add-gr-btn.add-contact, .edit-btn.edit.contact').click(function(){
		$('.overlay').fadeIn(250, function(){
			$('#contact-popup').animate({'top': $(window).scrollTop() + 100}, 500);
		});
		return false;
	});
	$('.overlay, #contact-popup .cancel-btn, #contact-popup .close').click(function(){
		$('#contact-popup').animate({'top': '-3000px'}, 500, function(){
			$('.overlay').fadeOut(250);
		});
		return false;
	});
    
    /* Access Popup */
	$('.add-gr-btn.add-access, .edit-btn.edit.access').click(function(){
		$('.overlay').fadeIn(250, function(){
			$('#access-popup').animate({'top': $(window).scrollTop() + 100}, 500);
		});
		return false;
	});
	$('.overlay, #access-popup .cancel-btn, #access-popup .close').click(function(){
		$('#access-popup').animate({'top': '-3000px'}, 500, function(){
			$('.overlay').fadeOut(250);
		});
		return false;
	});
    
    /* KP Popup */
	$('.add-gr-btn.add-kp, .edit-btn.edit.kp').click(function(){
		$('.overlay').fadeIn(250, function(){
			$('#kp-popup').animate({'top': $(window).scrollTop() + 100}, 500);
		});
		return false;
	});
	$('.overlay, #kp-popup .cancel-btn, #kp-popup .close').click(function(){
		$('#kp-popup').animate({'top': '-3000px'}, 500, function(){
			$('.overlay').fadeOut(250);
		});
		return false;
	});
    
    /* Comm Popup */
	$('.tab-edit-btn.edit-comm').click(function(){
		$('.overlay').fadeIn(250, function(){
			$('#comm-popup').animate({'top': $(window).scrollTop() + 100}, 500);
		});
		return false;
	});
	$('.overlay, #comm-popup .cancel-btn, #comm-popup .close').click(function(){
		$('#comm-popup').animate({'top': '-3000px'}, 500, function(){
			$('.overlay').fadeOut(250);
		});
		return false;
	});
    
    /* Rekv Popup */
	$('.tab-edit-btn.edit-rekv').click(function(){
		$('.overlay').fadeIn(250, function(){
			$('#rekv-popup').animate({'top': $(window).scrollTop() + 100}, 500);
		});
		return false;
	});
	$('.overlay, #rekv-popup .cancel-btn, #rekv-popup .close').click(function(){
		$('#rekv-popup').animate({'top': '-3000px'}, 500, function(){
			$('.overlay').fadeOut(250);
		});
		return false;
	});
    
    /* Delete Popup */
	$('.edit-btn.delete').click(function(){
		$('.overlay').fadeIn(250, function(){
			$('#delete-popup').animate({'top': $(window).scrollTop() + 100}, 500);
		});
		return false;
	});
	$('.overlay, #delete-popup .cancel-btn, #delete-popup .close').click(function(){
		$('#delete-popup').animate({'top': '-3000px'}, 500, function(){
			$('.overlay').fadeOut(250);
		});
		return false;
	});
    
    /* Confirm Popup */
	$('.p-check-btn').click(function(){
        if($(this).find('input[type=checkbox]').prop('checked')) {
            $('.overlay').fadeIn(250, function(){
                $('#confirm-popup').animate({'top': $(window).scrollTop() + 100}, 500);
            });
        }
		return false;
	});
    $('.overlay, #confirm-popup .cancel-btn, #confirm-popup .close').click(function(){
        /* делаем чекбокс неактивным */
        $('.p-check-btn input:checkbox').prop('checked', false).trigger('refresh');
		
        $('#confirm-popup').animate({'top': '-3000px'}, 500, function(){
			$('.overlay').fadeOut(250);
		});
		return false;
	});
    
    /* Confirm Recovery Popup */
	$('.removed .rec-btn, .more-btn.back-btn').click(function(){
		$('.overlay').fadeIn(250, function(){
			$('#confirm-rec-popup').animate({'top': $(window).scrollTop() + 100}, 500);
		});
		return false;
	});
	$('.overlay, #confirm-rec-popup .cancel-btn, #confirm-rec-popup .close').click(function(){
		$('#confirm-rec-popup').animate({'top': '-3000px'}, 500, function(){
			$('.overlay').fadeOut(250);
		});
		return false;
	});
	
	/* Validation Forms */
    
	/* Login Form */
	$("#login-form").validate({
		success: "valid"
	});
    
    /* Client Form */
	$("#add-client-form").validate({
		success: "valid"
	});
    
    /* Contact Form */
	$("#add-contact-form").validate({
		success: "valid"
	});
    
    /* Access Form */
	$("#add-access-form").validate({
		success: "valid"
	});
    
    /* KP Form */
	$("#add-kp-form").validate({
		success: "valid"
	});
    
    /* Comm Form */
	$("#add-comm-form").validate({
		success: "valid"
	});
    
    /* Rekv Form */
	$("#add-rekv-form").validate({
		success: "valid"
	});
    
    /* Payments Form */
	$("#add-payments-form").validate({
		success: "valid"
	});
    
    /*Yandex Maps Markers*/
    if($('.map').length) {
        ymaps.ready(init);
    }

    function init () {

        var myMap = new ymaps.Map("map", {
            center: [54.630310, 39.709883],
            zoom: 16,
            controls: ['zoomControl']
        });

        var myGeoObjects = [];

        myGeoObjects[0] = new ymaps.Placemark([54.630310, 39.709883],{
            clusterCaption: 'Заголовок', 
            //balloonContentBody: 'Текст в балуне',
        },{
            // Необходимо указать данный тип макета.
            iconLayout: 'default#image',
            iconImageHref: 'images/map_point.svg',
            // Размеры метки.
            iconImageSize: [68, 68],
            // Смещение левого верхнего угла иконки относительно
            // её «ножки» (точки привязки).
            iconImageOffset: [-34,-34]
        });

        var clusterIcons=[{
            href:'/images/map_point.svg',
            size:[68,68],
            offset:[0,0]
        }];

        var clusterer = new ymaps.Clusterer({
            clusterDisableClickZoom: false,
            clusterOpenBalloonOnClick: false,
            // Устанавливаем стандартный макет балуна кластера "Карусель".
            clusterBalloonContentLayout: 'cluster#balloonCarousel',
            // Устанавливаем собственный макет.
            //clusterBalloonItemContentLayout: customItemContentLayout,
            // Устанавливаем режим открытия балуна. 
            // В данном примере балун никогда не будет открываться в режиме панели.
            clusterBalloonPanelMaxMapArea: 0,
            // Устанавливаем размеры макета контента балуна (в пикселях).
            clusterBalloonContentLayoutWidth: 300,
            clusterBalloonContentLayoutHeight: 200,
            // Устанавливаем максимальное количество элементов в нижней панели на одной странице
            clusterBalloonPagerSize: 5
            // Настройка внешего вида нижней панели.
            // Режим marker рекомендуется использовать с небольшим количеством элементов.
            // clusterBalloonPagerType: 'marker',
            // Можно отключить зацикливание списка при навигации при помощи боковых стрелок.
            // clusterBalloonCycling: false,
            // Можно отключить отображение меню навигации.
            // clusterBalloonPagerVisible: false
        });

        clusterer.add(myGeoObjects);
        myMap.geoObjects.add(clusterer);
    }
});